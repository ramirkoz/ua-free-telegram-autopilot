"""UA FREE Telegram Autopilot."""

__version__ = "2.0.0-rc57"
APP_NAME = "UA FREE Telegram Autopilot V2"
