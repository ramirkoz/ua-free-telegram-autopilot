# UA FREE Telegram Autopilot v2.0.0-rc53

RC53 hardens event-level duplicate blocking after another live CTRL+UA paraphrase escaped RC52.

## Duplicate protection

- Fixed false `strong event/version/product code` conflicts caused by ordinary prose such as `inside 1.6 million` or `in 21 days`; strong codes no longer accept a plain space between a word and a number.
- Added named-entity + normalized fact fingerprints for aggressive rewrites of the same concrete event.
- Normalizes quantities such as `1.6 million` and grouped numbers, plus equivalent durations such as `21 days` and `three weeks`.
- Adds action/object families (hack, dismantle, discover, camera, capture, storage, transfer, access, privacy, law enforcement) so a brand name or number alone can never decide a duplicate.
- High-confidence event fingerprints now work across sources and for same-source republishes.
- Keeps the RC52 seven-day published-history pre-send gate and bounded source collection.

## Live regression

The two Flock camera posts reported by the operator are now classified as the same event, while an unrelated Flock camera contract story remains distinct.
